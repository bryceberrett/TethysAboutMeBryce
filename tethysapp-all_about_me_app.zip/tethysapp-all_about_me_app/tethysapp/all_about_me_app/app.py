from tethys_sdk.base import TethysAppBase, url_map_maker


class AllAboutMeApp(TethysAppBase):
    """
    Tethys app class for All About Me App.
    """

    name = 'All About Me App'
    index = 'all_about_me_app:home'
    icon = 'all_about_me_app/images/icon.gif'
    package = 'all_about_me_app'
    root_url = 'all-about-me-app'
    color = '#27ae60'
    description = 'This is for a class project'
    tags = ''
    enable_feedback = False
    feedback_emails = []

    def url_maps(self):
        """
        Add controllers
        """
        UrlMap = url_map_maker(self.root_url)

        url_maps = (
            UrlMap(
                name='home',
                url='all-about-me-app',
                controller='all_about_me_app.controllers.home'
            ),
            UrlMap(
                name='map',
                url='all-about-me-app/map',
                controller='all_about_me_app.controllers.map'
            ),
        )

        return url_maps